#include <iostream>
#include <string>

using namespace std;

class DVD {

public: 
	string DVD_CODE; 
	string title; 

};

class DVDShop {

public: 
	string shop_name; 
	DVD dvds[2]; 

};

class Customer {

public: 
	string name; 
	DVD dvd[1]; 
	DVDShop shop[1]; 

};

int main() {

	// create a DVD Shop 
	DVDShop shop; 
	shop.shop_name = "test shop"; 

	// create DVD's 
	DVD dvd1; 
	dvd1.DVD_CODE = "1"; 
	dvd1.title = "Scream 5"; 

	DVD dvd2; 
	dvd2.DVD_CODE = "2"; 
	dvd2.title = "Warsaw 44"; 

	// add DVD's to shop 
	shop.dvds[0] = dvd1; 
	shop.dvds[1] = dvd2; 


	Customer c; 
	c.name = "Lara McNeil"; 
	c.dvd[0] = dvd1; 
	c.shop[0] = shop;

	cout << "	" << endl; 
	cout << "DVD's in " + shop.shop_name << endl; 


	for (int index = 0; index < 2; index++) {
		cout << "DVD Code: "; 
		cout << shop.dvds[index].DVD_CODE + " "; 
		cout << "DVD Title: ";
		cout << shop.dvds[index].title << endl; 
	}

	cout << "	" << endl; 
	cout << c.name + " Has Purchased: " << endl; 


	for (int index = 0; index < 1; index++) {

		cout << "DVD Name: " + c.dvd[index].title + " From: "; 
		cout << "Shop Name: " + c.shop[index].shop_name << endl; 

	}


}